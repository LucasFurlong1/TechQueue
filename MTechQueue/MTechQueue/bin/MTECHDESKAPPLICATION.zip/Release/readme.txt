Hello everyone!
This is Lucas from the past. 
I am hopefully enjoying my time in Latvia and you are surviving the corporate environment.

This program is to help solve the problem of overflow on the MTech desk locations in 985 and 989.

To run this program, open the net5.0-windows folder and run the .exe file. 

Hopefully at this point, Carbon Black will let you run it. 

Enjoy!

Send any bugs to my email lucas.furlong@meijer.com or write them down and tell me when I get back and I will do my best to fix them.

Or just consider it broken and throw the whole program away, I don't care. 


IF SENDING BUGS TO MY EMAIL: put in the subject "MTECH DESK BUG" only. I have a rule set up so it goes into a different folder.


